public class ErrorFunctions {

    /*
    * Cases that cause errors:
    * 1. age = 4 && distance = 10
    * 2. age = 14 && distance = 10
    * 3. age = 15 && distance = 10
    * */
    public static int calculateFare(int age, int distance) {
        int fare = 0;
        if (age > 4 && age < 14) { // correct statement: if (age >= 4 && age <= 14)
            if (distance >= 10) { // correct statement: if (distance > 10)
                fare = 130;
            } else {
                fare = 100;
            }
        } else if (age > 15) { // if(age >= 15)
            if (distance < 10 && age >= 60) {
                fare = 160;
            } else if (distance > 10 && age < 60) { // correct statement: else if(distance >= 10 && age < 60)
                fare = 250;
            } else {
                fare = 200;
            }
        }
        return fare;
    }

    /*
     * Cases that cause errors:
     * 1. hour = 0
     * 2. hour = 23
     * 3. minute = 0
     * 4. minute = 59
     * 5. second = 0
     * 6. second = 59
     * */
    public static boolean checkValidTime(int hour, int minute, int second) {
        if (hour > 0 && hour < 23) { // correct statement: if (hour >= 0 && hour <= 23)
            if (minute > 0 && minute < 59) { // correct statement: if (minute >= 0 && minute <= 59)
                if (second > 0 && second < 59) { // correct statement: if (second >= 0 && second <= 59)
                    return true;
                }
            }
        }
        return false;
    }

    /*
     * Cases that cause errors:
     * 1. a < 0
     * 2. b < 0
     * 3. c < 0
     * 4. a + b = c && a > 0 && b > 0 && c > 0
     * 5. a + c = b && a > 0 && b > 0 && c > 0
     * 6. b + c = a && a > 0 && b > 0 && c > 0
     * */
    public static void triangleType(int a, int b, int c) {
        if (a != 0 && b != 0 && c != 0) { // correct statement: if (a > 0 && b > 0 && c > 0)
            if (a + b >= c || a + c >= b || b + c >= a) { // correct statement: if (a + b > c || a + c > b || b + c > a)
                if (a == b && b == c)
                    System.out.println("Equilateral Triangle");

                else if (a == b || b == c || c == a)
                    System.out.println("Isosceles Triangle");

                else
                    System.out.println("Scalene Triangle");
            }
        }
    }

    /*
     * Cases that cause errors:
     * 1. math + english >= 120 && math + english < 150
     * 2. math + english >= 100 && math + english < 120
     * */
    public static char convertGrade(int math, int english) {
        if (math <= 100 && math > 0 && english <= 100 && english > 0) {
            if (math + english >= 180) {
                return 'A';
            } else if (math + english >= 150) {
                return 'B';
            } else if (math + english >= 120) {
                if (math < 60 && english < 60) { // correct: remove this if statement
                    return 'C';
                }
            } else if (math + english >= 100) {
                if (math < 50 && english < 50) { // correct: remove this if statement
                    return 'D';
                }
            }
        }
        return 'X';
    }

    /*
     * Cases that cause errors:
     * 1. n1 != n2 && min(n1, n2) > n3
     * 2. n1 != n2 && min(n1, n2) = n3
     * */
    public static int findMax(int n1, int n2, int n3) {
        int maxN1N2;
        if (n1 < n2) { // correct statement: if (n1 > n2)
            maxN1N2 = n1;
        } else {
            maxN1N2 = n2;
        }

        if (maxN1N2 > n3) {
            return maxN1N2;
        } else {
            return n3;
        }
    }

    /*
     * Cases that cause errors:
     * 1. index = 0
     * 2. index > 0
     * */
    public static double intPow(double number, int index) {
        double result = 1;
        if (index == 0) return 0; // correct statement: if (index == 0) return 1;
        else if (index < 0) {
            for (int i = 0; i < -index; i++) {
                result *= number;
            }
            return 1 / result;
        } else {
            for (int i = 0; i < index; i++) {
                result *= number;
            }
            return -result; // correct statement: return result;
        }
    }

    /*
     * Cases that cause errors:
     * 1. weight = 0
     * 2. height = 0
     * */
    public static double calculateBMI(double weight, double height) {
        if (weight < 0 || height < 0) { // correct statement: if (weight <= 0 || height <= 0)
            return -1;
        }
        return weight / (height * height);
    }

    /*
     * Cases that cause errors:
     * 1. day = 1
     * 2. day = 31
     * 3. month = 1
     * 4. month = 12
     * 5. year = 1
     * 6. year = 2024
     * */
    public static boolean isValidDate(int day, int month, int year) {
        if (day > 1 && month > 1 && year > 1 && day < 31 && month < 12 && year < 2024) { // "="
            if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && (day <= 31))
                return true;
            if ((month == 4 || month == 6 || month == 9 || month == 11) && (day <= 30)) return true;
            if ((month == 2) && (day < 28)) return true;
            if ((month == 2) && (day == 29) && (year % 4 == 0) && (year % 400 != 0)) return true;
        }
        return false;
    }

    /*
     * Cases that cause errors:
     * 1. a > b
     * 2. a < b > c
     * 3. a < b < c > d
     * */
    public static boolean isAscending(int a, int b, int c, int d) {
        if (a <= b && b <= c && c <= d) {
            return true;
        }
        if (a > 0 && a < 0) { // correct: remove this if statement
            return false;
        }
        return true; // correct: remove this return statement
    }


}
